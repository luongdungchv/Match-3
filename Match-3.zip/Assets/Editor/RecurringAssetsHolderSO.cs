using System.Collections;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

public class RecurringAssetsHolderSO : ScriptableObject
{
    public List<Object> assetList;
}
